Readme

Mercedes-Benz amp

Hope you like the amp
I took away the EQ bars so that the car could be seen better.Please use the preset button for EQ settings
 
Made by Tiaan Kotze,South-Africa
E-mail,TIAAN72@MWEB.CO.ZA